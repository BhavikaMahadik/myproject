<!DOCTYPE html>
<html>
<head>
	<title>Aahinsa Society</title>
	<link rel="stylesheet" type="text/css" href="css/admincss.css">

<script src="https://code.jquery.com/jquery-3.2.1.js">
	</script>
	<script src="userlog.js" ></script>


	
	
	</head>
<body>
    <div class="login-form"><div class="backop"><div class="op">
        <!--<form  align="center"  action="" method="post"> -->  
       <div class="formtxt">

		   	
				
                <label >Username:</label>
                <input type="text" placeholder="Enter Your Username" id="user" name="user" required align="center"><br><br>
                <label >Password:</label>
                <input type="password" placeholder="Enter Your Password" id="pwd" name="pwd" required align="center"><br><br>
					<span id="loginmsg"></span>
				<!--<input type="submit" align="center" id="btn" value="submit" name="submit" >-->
		   	<button type="submit" id="btn" onclick="login()">Login</button>
		   
	
    </div>    </div>
        </div></div>


</body>
</html>    
		