<!DOCTYPE html>
<html>
<head>
<title>voice of Hope</title>
<link rel="stylesheet"  href="css/main.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="nav.js"></script>
</head>

<body>
<div class="head">
	<div class="cover">
	<div class ="opcty">
		<div class="nav">
			<nav class=" navbar  navbar-fixed-top navbar-default " >				
				<div class="container-fluid">
					<div class="trprnt">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse" >
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>                        
							</button>
							<a class="navbar-brand" href="#" ><img src="images/logo.png" alt="Dispute Bills" height="20px" width="20px" padding-right="50px"></a>		
						</div>
						<div class="topmenu collapse navbar-collapse" id="nav_bar">
							<ul class="nav navbar-nav " >
									<li class="active"><a href="index.php">Home</a></li>
									<li ><a href="#sspy2">About Us</a></li>
									<li ><a href="#sspy3">Contact Us</a></li>
									
			
							</ul>
										<ul class="nav navbar-nav navbar-right">
											<li><a href="admin.php"><span class="glyphicon glyphicon-user"></span>Admin</a></li>
											<li><a href="user.php"><span class="glyphicon glyphicon-log-in"></span>Login</a></li>
										</ul>
						</div>
					</div>   
				</div>
			</nav>
		</div>
				
					<div class="container">
						<div class="vof">
              <div class="headfont" > <h1>Aahinsa Society</h1><h5>---voice of hope!!</h5></div>
						</div>
					</div>
				
        </div></div>
</div>
<div id="sspy1">
<div class="desc ">
	<div class="container">	
		<p >VOF colony is located in kamothe sector-18 & it was build in 2000.It has 8 wings and very beautiful surrounding environment.
			It have very huge parking.There are various rules and regulations of colony .Each member of colony follows that.
			And we think Its a best place to live life peacefully.
			Do you think we can advance without society? Society is important because it provides us with a system and a platform to work 
			together for the betterment of the world. With the collective efforts of the society, we are able to improve our living and
			social conditions. For example; We have electricity, because someone invented the idea of electricity generation and its use. 
			We are advancing due to the collective social efforts. Without society, we are just homo sapiens (animals).
		</p>
	</div>
</div>

<div class="carousel">
<?php include ("carousel.php") ;?>
</div>

    </div>

</body>
</html>
